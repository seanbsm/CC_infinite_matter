#include "system.h"

System::System(Master* master)
{
    m_master = master;
}
