#include "pm.h"

PM::PM() /* Pairing Model */
{
}
