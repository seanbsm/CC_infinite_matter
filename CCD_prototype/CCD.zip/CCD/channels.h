#ifndef CHANNELS_H
#define CHANNELS_H

//channels is an object containing information about the available channels
class channels
{
public:
    channels();
    int size;
    int npp;
    int nhh;
};

#endif // CHANNELS_H
