#ifndef SETUPINTMAT_H
#define SETUPINTMAT_H

class SetupIntMat
{
public:
    SetupIntMat();
};

#endif // SETUPINTMAT_H
